(function(){
  // ===== 탭별 데이터 =====
  const DATA = {
    sales:{ title:"영업", groups:[
      { title:"사원관리", items:[
        { label:"사원관리", href:"/sales/emp" },
        { label:"수당등록", href:"/sales/allow" },
        { label:"공제등록", href:"/sales/deduct" },
      ]},
      { title:"부서관리", items:[ { label:"부서관리", href:"/sales/dept" } ]},
      { title:"급여관리", items:[
        { label:"급여대장", href:"/sales/payroll" },
        { label:"사원급여조회", href:"/sales/payview" },
        { label:"급여이체현황", href:"/sales/transfer" },
      ]},
    ]},
    inventory:{ title:"재고", groups:[
      { title:"자재관리", items:[
        { label:"자재발주서 등록", href:"/inv/order" },
        { label:"자재발주서 조회", href:"/inv/order/list" },
      ]},
      { title:"입고", items:[
        { label:"입고 등록", href:"/inv/in" },
        { label:"입고 현황", href:"/inv/in/list" },
      ]},
    ]},
    hr:{ title:"인사", groups:[
      { title:"사원관리", items:[
        { label:"사원관리", href:"/hr/emp" },
        { label:"수당등록", href:"/hr/allow" },
        { label:"공제등록", href:"/hr/deduct" },
      ]},
      { title:"부서관리", items:[ { label:"부서관리", href:"/hr/dept" } ]},
      { title:"급여관리", items:[
        { label:"급여대장", href:"/hr/payroll" },
        { label:"사원급여조회", href:"/hr/payview" },
        { label:"급여이체현황", href:"/hr/transfer" },
      ]},
    ]},
    accounting:{ title:"회계", groups:[
      { title:"전표관리", items:[
        { label:"전표등록", href:"/acc/voucher" },
        { label:"전표조회", href:"/acc/voucher/list" },
      ]},
    ]},
  };

  const $  = (s)=>document.querySelector(s);
  const $$ = (s)=>Array.from(document.querySelectorAll(s));

  function renderPill(tabKey){
    const data = DATA[tabKey] || DATA.hr;
    $('#pillTitle').textContent = data.title;
    const wrap = $('#pillGroups'); wrap.innerHTML='';

    data.groups.forEach(group=>{
      const sec=document.createElement('section'); sec.className='erp-group';
      const h=document.createElement('div'); h.className='erp-group-title'; h.textContent=group.title;
      const ul=document.createElement('ul'); ul.className='erp-list';

      group.items.forEach((it,idx)=>{
        const li=document.createElement('li'); li.className='erp-item';
        const a=document.createElement('a');
        a.href=it.href; a.textContent=it.label;
        a.className = idx===0 ? 'erp-link2' : 'erp-sublink';
        li.appendChild(a); ul.appendChild(li);
      });

      sec.appendChild(h); sec.appendChild(ul); wrap.appendChild(sec);
    });

    // 현재 URL에 맞춰 active 표시
    const path=location.pathname||'';
    wrap.querySelectorAll('a').forEach(a=>{
      if(path.startsWith(a.getAttribute('href'))){ a.classList.add('erp-active'); }
    });
  }

  function activateTab(btn){
    $$('.erp-tab').forEach(b=>b.classList.remove('erp-tab-active'));
    btn.classList.add('erp-tab-active');
    renderPill(btn.dataset.tab);
  }

  function init(){
    $$('.erp-tab').forEach(btn=>{
      btn.addEventListener('click',(e)=>{ e.preventDefault(); activateTab(btn); });
    });

    // 기본 탭: URL → 없으면 인사
    let key='hr';
    if(location.pathname.startsWith('/sales')) key='sales';
    else if(location.pathname.startsWith('/inv')) key='inventory';
    else if(location.pathname.startsWith('/acc')) key='accounting';

    const btn=$(`.erp-tab[data-tab="${key}"]`)||$('.erp-tab');
    if(btn) activateTab(btn);
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init);
  else init();
})();
